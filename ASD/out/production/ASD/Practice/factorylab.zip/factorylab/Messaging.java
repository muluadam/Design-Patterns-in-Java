package practice.factorylab;

public interface Messaging {

}
