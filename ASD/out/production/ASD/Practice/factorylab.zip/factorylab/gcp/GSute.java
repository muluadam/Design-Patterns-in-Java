package practice.factorylab.gcp;

import practice.factorylab.Messaging;

public class GSute implements Messaging {
    @Override
    public String toString() {
        return "G Suite";
    }
}
