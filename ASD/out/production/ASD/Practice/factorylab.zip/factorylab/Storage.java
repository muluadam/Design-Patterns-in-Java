package practice.factorylab;

public interface Storage {

}
