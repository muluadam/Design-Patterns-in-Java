package practice.factorylab.aws;

import practice.factorylab.Messaging;

public class AmazonSeS implements Messaging {



    @Override
    public String toString() {
        return "Amazon SES";
    }

}
