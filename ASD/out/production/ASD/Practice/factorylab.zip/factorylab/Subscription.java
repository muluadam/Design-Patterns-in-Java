package practice.factorylab;

public enum Subscription {
     FreeTrial, Basic, PayAsYouGo
}
