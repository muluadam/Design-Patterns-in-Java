package practice.factorylab.azure;

import practice.factorylab.Messaging;

public class MSExchange implements Messaging {
    @Override
    public String toString() {
        return "Microsoft Exchange";
    }
}
